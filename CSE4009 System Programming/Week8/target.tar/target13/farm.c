/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_409()
{
    return 2425393240U;
}

unsigned addval_200(unsigned x)
{
    return x + 3251079496U;
}

unsigned getval_321()
{
    return 3284633928U;
}

unsigned addval_274(unsigned x)
{
    return x + 851925168U;
}

void setval_231(unsigned *p)
{
    *p = 3284631880U;
}

unsigned getval_204()
{
    return 3284633928U;
}

void setval_238(unsigned *p)
{
    *p = 3281012838U;
}

unsigned addval_181(unsigned x)
{
    return x + 4173551740U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_422()
{
    return 3767093323U;
}

unsigned getval_249()
{
    return 3526934923U;
}

void setval_261(unsigned *p)
{
    *p = 3286272328U;
}

void setval_114(unsigned *p)
{
    *p = 3525367305U;
}

unsigned getval_401()
{
    return 3397985386U;
}

void setval_302(unsigned *p)
{
    *p = 3281046169U;
}

unsigned addval_417(unsigned x)
{
    return x + 3531915656U;
}

void setval_105(unsigned *p)
{
    *p = 3352725829U;
}

unsigned getval_240()
{
    return 3375939977U;
}

void setval_162(unsigned *p)
{
    *p = 3223374505U;
}

void setval_291(unsigned *p)
{
    *p = 3372794249U;
}

unsigned addval_379(unsigned x)
{
    return x + 2430635336U;
}

unsigned addval_421(unsigned x)
{
    return x + 3374891401U;
}

void setval_228(unsigned *p)
{
    *p = 3523791499U;
}

void setval_462(unsigned *p)
{
    *p = 3286270280U;
}

unsigned addval_404(unsigned x)
{
    return x + 3676886665U;
}

unsigned getval_479()
{
    return 3676357033U;
}

unsigned addval_326(unsigned x)
{
    return x + 3676362379U;
}

unsigned getval_263()
{
    return 3677935113U;
}

void setval_226(unsigned *p)
{
    *p = 3351757193U;
}

unsigned getval_264()
{
    return 2462746994U;
}

unsigned getval_222()
{
    return 3281049225U;
}

unsigned addval_227(unsigned x)
{
    return x + 3767093829U;
}

void setval_217(unsigned *p)
{
    *p = 3285621141U;
}

void setval_466(unsigned *p)
{
    *p = 2429192459U;
}

void setval_308(unsigned *p)
{
    *p = 3524840073U;
}

unsigned getval_338()
{
    return 3281043853U;
}

unsigned getval_398()
{
    return 2497743176U;
}

void setval_384(unsigned *p)
{
    *p = 3286272840U;
}

unsigned getval_136()
{
    return 3281049225U;
}

unsigned addval_259(unsigned x)
{
    return x + 3372796425U;
}

unsigned addval_407(unsigned x)
{
    return x + 2447411528U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
